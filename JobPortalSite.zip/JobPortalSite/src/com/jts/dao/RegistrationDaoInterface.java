package com.jts.dao;

import com.jts.bean.RegistrationBean;

public interface RegistrationDaoInterface {
	public boolean registerStudent(RegistrationBean rb);
}
